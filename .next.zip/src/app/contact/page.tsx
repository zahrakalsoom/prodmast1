import React from 'react'
import { Button } from '@/components/ui/button'

export default function page() {
  return (
    <div className=' flex flex-col'>this is contact page
        <Button variant={'outline'}> click me</Button>
    </div>
  )
}
