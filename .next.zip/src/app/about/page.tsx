import React from 'react'

export default function page() {
  return (
    <div>this about page
         <div className="text-3xl font-bold underline text-blue-600">
      Tailwind is working!
    </div>
    </div>
     
  )
}
